#ifndef KERNEL_H
#define KERNEL_H

struct uchar4;

void centroidParallel(uchar4 *img, int width, int height);

#endif