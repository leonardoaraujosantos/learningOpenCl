int main()
{
  int i;
  float x;
  i = 2;
  x = 1.3f;
	
  return 0;
}