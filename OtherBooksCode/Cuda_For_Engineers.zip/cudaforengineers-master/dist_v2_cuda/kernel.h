#ifndef KERNEL_H
#define KERNEL_H

// Kernel wrapper for computing array of distance values
void distanceArray(float *out, float *in, float ref, int len);

#endif