This repository contains the source code for the projects from [CUDA for Engineers][cudaoforengineers].

Linux/OS X Makefiles and Visual Studio 2013 project files are included with each project. In order to build the projects, [CUDA Toolkit 7.5][cudatoolkit] or above must be present on your system. 

[cudaoforengineers]: http://www.cudaforengineers.com
[cudatoolkit]: https://developer.nvidia.com/cuda-toolkit
