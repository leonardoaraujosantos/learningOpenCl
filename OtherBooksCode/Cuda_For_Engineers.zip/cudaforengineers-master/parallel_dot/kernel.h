#ifndef KERNEL_H
#define KERNEL_H

void dotLauncher(int *res, const int *a, const int *b, int n);

#endif