# Direct translation of the Matrix Matrix multiplication
This program isn't very performant at all as a general 
run took about 0.761s to perform a matrix-matrix multiplication
between two 1024x1024 matrices

Let's leave this be for now and we'll improve the performance
over the next few times

